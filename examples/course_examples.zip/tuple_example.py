from pprint import pprint

cisco_products  = ['Cisco 3620','Cisco 3640','Catalyst 7200']
ios_version = ['15.1','11.2','12.1']

network_dict = {k:v for (k,v) in zip(cisco_products,ios_version)}

#for paired in zip(cisco_products,ios_version):
#    print (paired)
#    network_dict[paired[0]] = paired[1]

pprint(network_dict)


