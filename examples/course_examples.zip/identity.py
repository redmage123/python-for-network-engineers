#!/usr/bin/env python3

a = 10
b = 11
c = 5
d = 5
s1 = 'xyzzy'
s2 = 'xyzzy'


print ('id a is ',id(a))
print ('id b is ',id(b))
print ('id c is ',id(c))
print ('id d is ',id(d))
print ('id s1 is ',id(s1))
print ('id s2 is ',id(s2))


if s1 == s2:
    print ('The value of s1 is the same as the value of s2')
else:
    print ('S1 and S2 do not have the same value')

if s1 is s2:
    print ('s1 and s2 are the same object')
else:
    print ('s1 and s2 are not the same object')
