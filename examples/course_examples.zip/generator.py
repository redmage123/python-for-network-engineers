#!/usr/bin/env python3

def my_generator():
    l = [1,2,3,4,5]
    for e in l:
        yield e

x = my_generator()
#while (1):
#    try:
#       num = next(x)
#       print (num)
#    except StopIteration:
#        print ('Finished')
#        break


for num in x:
    print (num)
print ('Finished')
