
colors_dict = { 'Red':0xff000000,'Green':0x00ff00, 'Blue':0x00000f}


if 'magenta' not in colors_dict:
    print ('No key magenta found!')


if 'magenta' not in  colors_dict.keys():
    print ('No key magenta found!')

try: 
    print (colors_dict['magenta'])
except KeyError as e:
   
    print ('No key magenta found!')




