#!/usr/bin/env python3

s1 = 'Hello World'
print (s1.lower())

