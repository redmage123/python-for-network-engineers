#!/usr/bin/env python3

import os
p = os.popen('netstat -rn','r')
out = p.read()
print (str(out).splitline())
