myd = {'Router1':{'ipaddress':'192.168.10.1', 'Vendor':'Cisco'}}

print (myd['Router1']['ipaddress'])

