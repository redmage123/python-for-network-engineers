#!/usr/bin/env python3

import multiprocessing as mp
from netmiko import ConnectHandler
from time import sleep


devs = [
        { 'device_type': 'generic_termserver_telnet',
                         'ip': '127.0.0.1',
                          'port': 2015
        },

        { 'device_type': 'generic_termserver_telnet',
                         'ip': '127.0.0.1',
                         'port': 2016
        }
]


def talk_to_router(dev_dict,rname,q):
    net_connect = ConnectHandler(**dev_dict)
    net_connect.write_channel('\r\n')
    net_connect.read_channel()
    net_connect.write_channel('show ip interface brief\r\n')
    sleep(2)
    output1 = net_connect.read_channel()
    net_connect.write_channel('show ip interface brief\r\n')
    net_connect.read_channel()
    net_connect.write_channel('show arp\r\n')
    output2 = net_connect.read_channel()
    q.put((rname,output1,output2))



if __name__ == '__main__':
    
    jobs = []
    results = []
    q = mp.Queue()
    p = mp.Process(target = talk_to_router, args = (devs[0],'R3',q))
    jobs.append(p)
    p.start()
    p = mp.Process(target = talk_to_router, args = (devs[1],'R4',q))
    jobs.append(p)
    p.start()

    for job in jobs:
        job.join()

    while not q.empty():
        results.append(q.get())

    print (results)
