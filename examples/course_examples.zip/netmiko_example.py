#!/usr/bin/env python3


from netmiko import ConnectHandler, redispatch
import time

cisco_7200 = {
              'device_type': 'generic_termserver_telnet',
              'ip': '127.0.0.1',
              'port':2015,
}


net_connect = ConnectHandler(**cisco_7200)
net_connect.write_channel ('\r\n')
output = net_connect.read_channel()
net_connect.write_channel('show ip interface brief\r\n')
time.sleep(1)
output = net_connect.read_channel()
print (output)
net_connect.write_channel ('\r\n')
time.sleep(1)
net_connect.write_channel('show arp\r\n')
time.sleep(1)
output = net_connect.read_channel()
print (output)

#redispatch(net_connect, device_type = 'cisco_ios_telnet')
#new_output = net_connect.send_command('show ip int brief')
