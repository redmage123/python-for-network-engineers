#!/usr/bin/env python3

import threading as mt
import time

def worker_process(process_id):
    print ('I am a worker function: ' + str(process_id ))
    return

if __name__ == '__main__':
    jobs = []
    for job_id in range(5):
        p = mt.Thread(target=worker_process, args=(str(job_id)))
        jobs.append(p)
        p.start()

    p.join()
# Nothing will happen here, until all of the processes are finished...
# Other code here
