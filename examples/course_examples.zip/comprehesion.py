numbers = [1,2,3,4,5,6,7,8,9,10]
numbers_squared = [number** 2 for number in numbers ]
print (numbers_squared)

words = ['fee','fi','fo','fum']
upper_words = [word.upper() for word in words ]
print (upper_words)


even_numbers_squared = [ number ** 2 for number in numbers if number %2 == 0 ]
print (even_numbers_squared)


#numbers_squared = []
#
#for number in numbers:
#    numbers_squared.append(number **2)
#
#print (numbers_squared)

