class Animal:
    
    # Gender
    # Name
    # Age 
    # Owner's Name

    number_of_animals = 0
    @staticmethod
    def speak():
        pass
    
    def __init__(self, name,age,gender,owners_name):
        self.name = name
        self.age = age
        self.gender = gender
        self.owners_name = owners_name
        Animal.number_of_animals += 1

    def changeAge(self,newAge):
        self.age = newAge

    def changeName(self,newName):
        self.name = newName

        return

class Dog (Animal): 

    @staticmethod
    def speak():
        return 'Woof'

    def __init__(self,name,age,gender,owners_name,license_number):
        super().__init__(name,age,gender,owners_name)
        self.dog_license = DogLicense(owners_name,license_number)

    def RenewLicense(self):
         self.dog_license.renewLicense()

    def getLicenseNumber(self):
        return self.dog_license.returnLicenseNumber()


class Cat(Animal):

    @staticmethod
    def speak():
        return 'Meow'

    def __init__(self,name,age,gender,owners_name):
        super().__init__(name,age,gender,owners_name)
 

class Cow (Animal):

    @staticmethod
    def speak():
        return ('Moooo')

    def __init__(self,name,age,gender,owners_name):
        super().__init__(name,age,gender,owners_name)


    

class DogLicense:

     def __init__(self,owners_name,license_number):
        self.owners_name = owners_name
        self.license_number = license_number

     def returnLicenseNumber(self):
        return self.license_number

     def renewLicense(self):
         pass

if __name__ == '__main__':

    c = Cat('Fluffy',2,'F','Jane')
    d = Dog('Rex',3,'M','Joe',12345)
    cow = Cow('Bossie','F',4,'Joe')


    print (dir(c))
