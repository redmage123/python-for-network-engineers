#!/usr/bin/env python3
import re

IPs = ['192.168.100.1',
       '19.6.11.1',
       '255.255.255.0',
       '1111.2.3.4',
       '1.2.3.4567',
       '10.0.0.1',
 ]

RE = r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$'
for ip in IPs:
    matchobj = re.search(RE,ip)
    if matchobj:
        for i in range(1,5):
            if matchobj.group(i) > 0 and <256
                continue
            else:
                break
    
        else:
            print ('Valid IP address ', ip)
