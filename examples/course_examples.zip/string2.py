#!/usr/bin/env python3

#print ('Hi there'.upper())

data = 'Braun Brelin,21,1234 Main Street,Anytown,USA\n'

(name,age,addr,city,country) = data.strip().split(',')

age = int(age) +1

newdata = ",".join((name,str(age),addr,city,country))
print (newdata)
