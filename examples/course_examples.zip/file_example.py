import sys

try:
    f = open('/etc/passwd')
except IOError:
    print ('IOError')
    sys.exit(1)


try:
    for line in f:
        print (line.strip()
except IOError:
    print ('IO Error occurred.  Bailing out')
    sys.exit(1)
finally:
    f.close()

buffer_size=1024

    f = open('/some/binary/file' ,'rb'):
    buf = f.read(buffer_size)
          f.write(buffer_size)
        
    f.seek(0)
    f.tell()
sys.exit(0)

