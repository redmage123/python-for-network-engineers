#!/usr/bin/env python3



x = input('Please enter a number: ')
print ('You typed in a an ', x)

x = int(x) + 1

print ('The new value of x is ',x)
