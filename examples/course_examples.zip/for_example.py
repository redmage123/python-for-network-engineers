colors = ['Red','Green','Blue']


for color in colors:
    print (color)


#print (len(colors))


#for i in range(10):
#    print (i)


#for i in range(3,10):
#    print (i)


#for i in range(len(colors)):
#    print (colors[i])
