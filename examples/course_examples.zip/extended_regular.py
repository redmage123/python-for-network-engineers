#!/usr/bin/env python3

import re

URLs = ['https://www.cnn.com',
        'google.co.uk',
        'htp://globalknowledge.co.uk',
        'www.facebook.',
        'harvard.edu',
        'http://timesoflondon.co.uk',
        'slashdot.net'
]


RE = r'^(https?://)?(\w+\.)+(com|co\.uk|edu|net)$'
for url in URLs:
    matchobj = re.search(RE,url)
    if matchobj:
        if 'https?://' not in matchobj.group(1)     
             print ('https://' + matchobj.string)
        else:
            print (matchobj.string)
#        
