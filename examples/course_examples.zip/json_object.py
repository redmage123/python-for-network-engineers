#!/usr/bin/env python3

class Employee:
    def __init__(self):
        self.name = 'Braun Brelin'



e = Employee()

print (e.__dict__)
