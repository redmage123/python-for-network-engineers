#!/usr/bin/env python3


x = 5

if x == 5:
    print ('Line 1')
    print ('Line 2')


