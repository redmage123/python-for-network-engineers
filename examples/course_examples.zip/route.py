#!/usr/bin/env python3
import os

route_output = os.system('netstat -r')
print (route_output[0:8])
