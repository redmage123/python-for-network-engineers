#!/usr/bin/env python3

a = 2
b = 2


if a == 1 and b == 2:
    print ('both are true')
else:
    print ('both are not true')
