import vet_clinic
from vet_clinic import Animal

print ('__name__ = ',vet_clinic.__name__)

print ('In the vet application')



