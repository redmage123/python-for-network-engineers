#!/usr/bin/env python3


# We are going to calculate the volume of a sphere. 

#4 / 3 * PI * the cube of the radius

'''
Step 1. 

Create two variables. 
Variable 1 is the identifier PI, set it to the value of pi, for example
PI = 3.1415927

Variable 2 is the radius

Assign a value to the radius

Print out the volume of the sphere with the radius that you assigned to it. 


Step 2. 

You are going to ask the user for the radius
calculate the volume of the sphere. 

Step 3.  

Put the calculation for the volume, the area and the circumference of the
sphere into its own functions.  Pass the radius into the functions and
return the calculation. 

Volume = 4 /3 * pi * radius ** 3
Area = pi x r squared
circum = 2 X pi x r

'''


#PI = 3.1415927
#radius = 3
#
#volume = 4 /3 * PI * radius ** 3
#print ('Volume = ', volume)


from math import pi
def calculate_volume(r=2):
    return 4 /3 *  pi * r **3

def calculate_area(r=2):
    return pi * r ** 2

def calculate_circumference(r=2):
    return 2 * pi * r


radius = float(input('Please enter a radius: '))

print('%.3f' % (calculate_volume(radius)))
print('%.3f' % calculate_area(radius))
print('%.3f' % calculate_circumference(radius))

