import sys



def func divide(x,y):
    if y == 0:
        raise DivideByZeroError
    else:
       return x/y

while True:
    try: 
        x = input('Please enter a number: ')
        x = int(x)
    except ValueError:
        print ('Invalid number!')
    else:
        break
    finally: 
        print ('Something happened here')

print (x + 1)
