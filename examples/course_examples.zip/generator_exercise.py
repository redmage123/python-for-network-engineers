#!/usr/bin/env python3

def EvenGenerator(n):
# set a starting value (probably 0)
# is the starting value > than the n value passed in?
# If so, you're done
# otherwise
# if the  starting value is even, yield back that value
# increment the starting value

    i = 0
    while i <= n:
        if i % 2 == 0:
            yield i
        i += 1

# Complete this part
    pass

n = int(input('Please enter a number: '))
values = []
for k in EvenGenerator(n):
    values.append(str(k))

print (','.join(values))


