
def funca():
   return ('This is function a')

def funcb():
   return ('This is function b')

def funcc():
   return ('This is function c')

myvariable = 0
mylist = [1,2,3,4,5]
