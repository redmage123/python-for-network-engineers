import mymodule

from mymodule import funca,funcb,funcc
import numpy as np 

np.asarray(a)

#print ('the value of mymodule.myvariable = ',mymodule.myvariable)
#print (mymodule.funca())
print (funca())
print (funcb())
print (funcc())

#print (mymodule.mylist[0])
