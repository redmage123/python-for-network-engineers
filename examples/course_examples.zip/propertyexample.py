#!/usr/bin/env python3

class Project:

   def __init__(self,title,department, budget,manager,amountSpent):
       self.title = title
       self.department = department
       if budget > 0:
           self.budget = budget
       else:
           raise ValueError
       self.manager = manager
       self.amountSpent = amountSpent

   def amountOfBudgetLeft(self):
       return self.budget - self.amountSpent

   def setBudget(self,amount):
       self.budget = amount

   @property
   def budget(self):
       return self.budget

   @budget.setter
   def budget(self,amountToSet):
       if amountToSet < 0:
           raise ValueError
       self.budget = amountToSet

myprog = Project('Project1','Engineering',10000,'John Smith',0)
#myproj.budget = 100000
print (myproj.budget)






